"use client";

import { ConfigProvider,  theme as antdTheme } from "antd";
import { ProConfigProvider } from "@ant-design/pro-components";
import { SWRConfig } from "swr";
import React, { useState } from "react";
import { AntdRegistry } from "@ant-design/nextjs-registry";
import '@ant-design/v5-patch-for-react-19';

import "antd/dist/reset.css"; 
import "./globals.css";

const customAlgorithm = (token: any) => ({
  ...antdTheme.defaultAlgorithm(token),
  colorSuccess: "#231a61",
  colorInfo: "#471A61",
  colorWarning: "#611A57",
  colorError: "#61231A",
});

export default function RootLayout({ children }: { children: React.ReactNode }) {    
  return (
    <html>
      <body style={{ margin: 0, padding: 0 }}>
        <AntdRegistry>
        <SWRConfig value={{ provider: () => new Map() }}>
          <ProConfigProvider hashed={false}>
            <ConfigProvider
              theme={{
                algorithm: customAlgorithm,
                token: {
                  colorPrimary: "#E72F29",
                },
              }}
            >
              {children}
            </ConfigProvider>
          </ProConfigProvider>
        </SWRConfig>
        </AntdRegistry>
      </body>
    </html>
  );
}