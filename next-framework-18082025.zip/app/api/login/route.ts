import { NextResponse } from "next/server";
import { encrypt } from "@/lib/auth";
import { z } from "zod";

const expiresIn = parseInt(process.env.EXPIRES_IN || "900", 10); // default to 900 seconds (15 minutes)

const messages = {
  en: {
    usernameMin: "Username must be at least 3 characters",
    passwordMin: "Password must be at least 6 characters",
  },
  id: {
    usernameMin: "Username minimal 3 karakter",
    passwordMin: "Password minimal 6 karakter",
  },
};

type Lang = "en" | "id";

export async function POST(req: Request) {
  const lang = (req.headers.get("x-lang") as Lang) || "en";
  const msg = messages[lang];

  const loginSchema = z.object({
    username: z.string().min(3, msg.usernameMin),
    password: z.string().min(6, msg.passwordMin),
    });

  try {
    const body = await req.json();    
    const { username, password } = loginSchema.parse(body);

    if (username === "admin" && password === "password") {
        const res = NextResponse.json({ success: true });
        
        const user = {username: username, name: "Admin"};
        const expires = new Date(Date.now() + expiresIn * 1000);
        const session = await encrypt({ user, expires });
        res.cookies.set("session", session, { expires, httpOnly: true, path: "/"});

        return res;
    }

    return NextResponse.json({ success: false }, { status: 401 });
  } catch (err: any) {
    if (err instanceof z.ZodError) {
        return NextResponse.json(
        { error: err.issues[0].message }, 
        { status: 400 }
        );
    }
    return NextResponse.json(
        { error: "Internal server error" }, 
        { status: 500 }
    );
    }
}
