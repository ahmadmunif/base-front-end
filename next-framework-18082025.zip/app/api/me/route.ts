import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { decrypt, getSession } from "@/lib/auth";

export async function GET() {
  const session = await getSession();

  if (!session) {
    return NextResponse.json({ user: null }, { status: 401 });
  }

  try {
    const { user } = session;
    return NextResponse.json({ user });
  } catch (e) {
    return NextResponse.json({ user: null }, { status: 401 });
  }
}
