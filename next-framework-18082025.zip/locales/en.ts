import Password from "antd/es/input/Password";
import { fail } from "assert";
import { success } from "zod";

export default {
  hello: "Hello",
  switchLanguage: "Switch Language",  
  logout: "Logout",
  login: {
    title: "telkomsigma",
    subTitle: "Login to management system",
    button: "Login",
    success: "Login successful",
    fail: "Login failed",
    form: {
      username: {
        placeholder: "Username",
        required: "Please enter your username!",
      },
      password: {
        placeholder: "Password",        
        required: "Please enter your password!",
      },
    },
  },
};
