export default {
  hello: "Halo",
  switchLanguage: "Ganti Bahasa",
  logout: "Keluar",
  login: {
    title: "telkomsigma",
    subTitle: "Masuk ke sistem manajemen",
    button: "Masuk",
    success: "Masuk berhasil",
    fail: "Masuk gagal",
    form: {
        username: {
            placeholder: "Nama Pengguna",
            required: "Silakan masukkan nama pengguna Anda!",
        },
        password: {
            placeholder: "Kata Sandi",        
            required: "Silakan masukkan kata sandi Anda!",
        },
    },
  },
};