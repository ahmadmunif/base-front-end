import Password from "antd/es/input/Password";
import { fail } from "assert";
import { success } from "zod";
import { required } from "zod/mini";

export default {
  hello: "Hello",
  switchLanguage: "Switch Language",  
  logout: "Logout",
  login: {
    title: "telkomsigma",
    subTitle: "Login to management system",
    button: "Login",
    success: "Login successful",
    fail: "Login failed",
    form: {
      username: {
        placeholder: "Username",
        required: "Please enter your username!",
      },
      password: {
        placeholder: "Password",        
        required: "Please enter your password!",
      },
    },
  },
  userManagement: {
    user: {
      title: "User Management",
      resetButton: "Reset",
      saveButton: "Save",
      createButton: "Create New User",
      fail: "Create user failed",
      success: "Create user successful",
      form : {
        username: {
          label: "Username",
          tooltip: "This is a required field and must be unique.",
          placeholder: "enter your username",
          required: "Username is required",
        },
        fullname: {
          label: "Full Name",
          placeholder: "enter your full name",
          required: "Please enter your full name",
        },
        email: {
          label: "Email",
          placeholder: "enter your email",
          required: "Please enter a valid email address",
        },
        password: {
          label: "Password",
          placeholder: "type your password",
          required: "Password is required",
          minLength: "Minimum 6 characters",
        },
        confirmPassword: {
          label: "Confirm Password",
          placeholder: "retype your password",
          required: "Please confirm your password",
          mismatch: "The two passwords that you entered do not match!",
        },
        status: {
          label: "Status",
          placeholder: "Select status",
          required: "Status is required",
        },
      },
    },

  },
};
