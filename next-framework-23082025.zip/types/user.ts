import { z } from "zod";

export const createUserSchema = z.object({
  username: z.string().min(3).max(100),
  email: z.string().email().max(150),
  password: z.string().min(6),   // plain password (akan di-hash)
  passwordHash: z.string().optional(), // untuk update, kalau tidak diisi, password tidak berubah
  full_name: z.string().max(150).optional(),
  is_active: z.boolean().optional().default(true),
});

export type CreateUserInput = z.infer<typeof createUserSchema>;
