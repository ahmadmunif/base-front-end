import { NextResponse } from "next/server";
import { createUserSchema } from "@/types/user";
import { UserService } from "@/services/userService";

export async function POST(req: Request) {
  const userService = new UserService();
  try {
    const body = await req.json();
    const parsed = createUserSchema.parse(body);
    const user = await userService.create(parsed);

    return NextResponse.json({ success: true, user });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 400 });
  }
}
