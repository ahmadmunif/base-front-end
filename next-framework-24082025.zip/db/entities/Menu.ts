import {
  Entity, PrimaryGeneratedColumn, Column,
  CreateDateColumn, UpdateDateColumn, ManyToOne, OneToMany, ManyToMany
} from "typeorm";
import { Role } from "./Role";

@Entity("menus")
export class Menu {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ length: 100 })
  name!: string;

  @Column({ length: 200 })
  path!: string;

  @Column({ length: 100, nullable: true })
  icon?: string;

  @ManyToOne(() => Menu, menu => menu.children, { onDelete: "CASCADE" })
  parent?: Menu;

  @OneToMany(() => Menu, menu => menu.parent)
  children!: Menu[];

  @CreateDateColumn({ name: "created_at" })
  createdAt!: Date;

  @UpdateDateColumn({ name: "updated_at" })
  updatedAt!: Date;

  @ManyToMany(() => Role, role => role.menus)
  roles!: Role[];
}
