import { getDataSource } from "@/db/data-source";
import { User } from "@/db/entities/User";
import bcrypt from "bcryptjs";
import { CreateUserInput } from "@/types/user";
import { Repository, FindOptionsWhere } from "typeorm";

export class UserService {
  private repoPromise: Promise<Repository<User>>;

  constructor() {
    this.repoPromise = getDataSource().then(ds => ds.getRepository(User));
  }

  private async repo() {
    return this.repoPromise;
  }

  async create(data: CreateUserInput) {
    const repo = await this.repo();
    if (await repo.findOne({ where: { username: data.username } })) {
      throw new Error("Username already exists");
    }

    const user = repo.create({
      ...data,
      // fullName: data.full_name,
      passwordHash: await bcrypt.hash(data.password, 12),
    });

    return repo.save(user);
  }

  async update(id: string, data: Partial<CreateUserInput>) {
    const repo = await this.repo();
    if (data.password) {
      data.passwordHash = await bcrypt.hash(data.password, 12);
      delete (data as any).password; // jangan simpan plaintext
    }
    await repo.update(id, data);
    return this.findById(id);
  }

  async checkPassword(plain: string, hashed: string) {
    return bcrypt.compare(plain, hashed);
  }

  async findById(id: string) {
    const repo = await this.repo();
    return repo.findOne({ where: { id } });
  }

  async delete(id: string) {
    const repo = await this.repo();
    return repo.delete(id);
  }

  async findAll() {
    const repo = await this.repo();
    return repo.find();
  }

  async findByUsername(username: string) {
    const repo = await this.repo();
    return repo.findOne({ where: { username } });
  }

  // async findAndCount(where: string, page: number, pageSize: number) {
  //   const repo = await this.repo();
  //   const [items, total] = await repo.findAndCount({
  //     where: where,
  //     skip: (page - 1) * pageSize,
  //     take: pageSize,
  //     order: { createdAt: "DESC" },
  //   });
  //   return { items, total };
  // }
  async findAndCount(where: FindOptionsWhere<User>, page: number, pageSize: number) {    
  const repo = await this.repo();
  const [items, total] = await repo.findAndCount({
    where,
    skip: (page - 1) * pageSize,
    take: pageSize,
    order: { createdAt: "DESC" },
  });
  return { items, total };
}
}
