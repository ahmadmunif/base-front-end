import { NextRequest, NextResponse } from "next/server";
import { updateSession } from "@/lib/auth";

export async function middleware(request: NextRequest) {
    const { pathname } = request.nextUrl;
    const lang = request.cookies.get("lang")?.value || "en";
    const headers = new Headers(request.headers);
    headers.set("x-lang", lang);

    if (
        pathname.startsWith("/login") ||
        pathname.startsWith("/logout") ||
        pathname.startsWith("/_next") ||
        pathname.startsWith("/images") ||
        pathname.startsWith("/api/login") ||
        pathname.startsWith("/api/logout")
    ) {
        return NextResponse.next({ request: { headers } });
    }

    try {
        const session = request.cookies.get("session")?.value;
        if (!session) {
            const res = NextResponse.redirect(new URL("/login", request.url));
            res.cookies.set("session", "", { expires: new Date(0), httpOnly: true, path: "/" });
            return res;
        } 
    } catch (err: any) {
        return NextResponse.redirect(new URL("/login", request.url));
    }

    await updateSession(request);
    
    

    return NextResponse.next({ request: { headers } });
}