import id from "@/locales/id";
import { z } from "zod";

export const createUserSchema = z.object({
  id: z.string().uuid().optional(), // untuk update
  username: z.string().min(3).max(100),
  email: z.string().email().max(150),
  password: z.string().min(6),   // plain password (akan di-hash)
  passwordHash: z.string().optional(), // untuk update, kalau tidak diisi, password tidak berubah
  fullName: z.string().max(150).optional(),
  isActive: z.boolean().optional().default(true),
});

export type CreateUserInput = z.infer<typeof createUserSchema>;
