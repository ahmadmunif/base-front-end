import { fi } from "zod/locales";
import { required } from "zod/mini";

export default {
  hello: "Halo",
  switchLanguage: "Ganti Bahasa",
  logout: "Keluar",
  login: {
    title: "telkomsigma",
    subTitle: "Masuk ke sistem manajemen",
    button: "Masuk",
    success: "Masuk berhasil",
    fail: "Masuk gagal",
    form: {
        username: {
            placeholder: "Nama Pengguna",
            required: "Silakan masukkan nama pengguna Anda!",
        },
        password: {
            placeholder: "Kata Sandi",        
            required: "Silakan masukkan kata sandi Anda!",
        },
    },
  },
  userManagement: {
    user: {
      title: "Manajemen Pengguna",
      resetButton: "Atur Ulang",
      saveButton: "Simpan",
      createButton: "Buat Pengguna Baru",
      fail: "Pembuatan pengguna gagal",
      success: "Pembuatan pengguna berhasil",
      editFail: "Pembaruan pengguna gagal",
      editSuccess: "Pembaruan pengguna berhasil",
      deleteConfirm: "Apakah Anda yakin ingin menghapus pengguna ini?",
      deleteSuccess: "Pengguna berhasil dihapus", 
      deleteFail: "Gagal menghapus pengguna",
      createNewUser: "Buat Pengguna Baru",
      editUser: "Sunting Pengguna",
      form: {
        username: {
          label: "Nama Pengguna",
          tooltip: "Ini adalah bidang wajib dan harus unik.",
          placeholder: "masukkan nama pengguna Anda",
          required: "Nama pengguna wajib diisi",
        },
        fullname: {
          label: "Nama Lengkap",
          placeholder: "masukkan nama lengkap Anda",
          required: "Silakan masukkan nama lengkap Anda",
        },
        email: {
          label: "Email",
          tooltip: "Ini adalah bidang wajib dan harus unik.",
          placeholder: "masukkan email Anda",
          required: "Silakan masukkan alamat email yang valid",
        },
        password: {
          label: "Kata Sandi",
          placeholder: "ketik kata sandi Anda",
          required: "Kata sandi wajib diisi",
          minLength: "Minimal 6 karakter",
        },
        confirmPassword: {
          label: "Konfirmasi Kata Sandi",
          placeholder: "ketik ulang kata sandi Anda",
          required: "Silakan konfirmasi kata sandi Anda",
          mismatch: "Kedua kata sandi yang Anda masukkan tidak cocok!",
        },
        status: {
          label: "Status",
          placeholder: "Pilih status",
          required: "Status wajib diisi",           
        }
      },
    },
  },
  showFilter: "Tampilkan Filter",
  hideFilter: "Sembunyikan Filter",
  find: "Cari",
  clear: "Bersihkan",
  showing: "Menampilkan",
  of: "dari",
  edit: "Sunting",
  delete: "Hapus",
};