import { NextResponse } from "next/server";

export async function POST() {
  try {
    const res = NextResponse.redirect(new URL("/login", process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"));

    res.cookies.set("session", "", {httpOnly: true, path: "/", maxAge: 0});

    return res;
  } catch (err) {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
