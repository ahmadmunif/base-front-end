import { NextResponse } from "next/server";
import { encrypt } from "@/lib/auth";
import { z } from "zod";
import { UserService } from "@/services/userService";


const expiresIn = parseInt(process.env.EXPIRES_IN || "900", 10); // default to 900 seconds (15 minutes)

const messages = {
  en: {
    usernameMin: "Username must be at least 3 characters",
    passwordMin: "Password must be at least 6 characters",
    invalidCredential: "Invalid credentials",
  },
  id: {
    usernameMin: "Username minimal 3 karakter",
    passwordMin: "Password minimal 6 karakter",
    invalidCredential: "Kredensial tidak valid",
  },
};

type Lang = "en" | "id";

export async function POST(req: Request) {
  const lang = (req.headers.get("x-lang") as Lang) || "en";
  const msg = messages[lang];
  const userService = new UserService();

  const loginSchema = z.object({
    username: z.string().min(3, msg.usernameMin),
    password: z.string().min(6, msg.passwordMin),
    });

  try {
    const body = await req.json();    
    const { username, password } = loginSchema.parse(body);

    const user = await userService.findByUsername(username);
    if (!user || !user.isActive) {
        return NextResponse.json({ error: msg.invalidCredential }, { status: 401 });
    }

    const valid = await userService.checkPassword(password, user.passwordHash);
    if (!valid) {
        return NextResponse.json({ error: msg.invalidCredential }, { status: 401 });
    }

    const res = NextResponse.json({ success: true });
    
    const userData = {username: username, name: user.fullName};
    const expires = new Date(Date.now() + expiresIn * 1000);
    const session = await encrypt({ userData, expires });
    res.cookies.set("session", session, { expires, httpOnly: true, path: "/"});

    return res;
  } catch (err: any) {
    console.error("Login error:", err);
    if (err instanceof z.ZodError) {
        return NextResponse.json(
        { error: err.issues[0].message }, 
        { status: 400 }
        );
    }
    return NextResponse.json(
        { error: "Internal server error: " + err.message }, 
        { status: 500 }
    );
    }
}
