'use client'; 

import React from 'react';
import {
  DefaultFooter,
  PageContainer,
  ProLayout,
} from '@ant-design/pro-components';
import { useState, useEffect, createContext } from 'react';

import {
  DashboardOutlined,
  BarChartOutlined,
  LogoutOutlined,
  UserOutlined,
  GlobalOutlined,
  TeamOutlined,
} from '@ant-design/icons';

import Link from 'next/link';
import { useRouter, usePathname } from 'next/navigation';
import { Dropdown, Button, ConfigProvider, Tooltip } from "antd";

import enUS from "antd/locale/en_US";
import idID from "antd/locale/id_ID";

import { locales, LocaleKey } from "@/locales";

import { LangContext } from "@/providers/LangProvider";

type LayoutProps = {
  children: React.ReactNode;
};

export default function Layout({ children }: LayoutProps) {
  const [user, setUser] = useState<{ username: String, name: string } | null>(null);
  const router = useRouter();
  const pathname = usePathname();
  const [mounted, setMounted] = useState(false);
  const [locale, setLocale] = useState<any>(enUS);
  const [currentLang, setCurrentLang] = useState<LocaleKey>("en");
  const texts = locales[currentLang];



   useEffect(() => {
    setMounted(true); 

    const savedLang = localStorage.getItem("lang") as "en" | "id" | null;
    if (savedLang) {
      setLocale(savedLang === "en" ? enUS : idID);
      setCurrentLang(savedLang);
    }

    (async () => {
      try {
        const res = await fetch("/api/me");
        if (res.ok) {
          const data = await res.json();
          setUser(data.userData);
        }
      } catch (err) {
        console.error("Failed to load user", err);
      }
    })();
  }, []);
  
  const handleLogout = async () => {
    await fetch("/api/logout", { method: "POST" });
    router.push("/login"); // redirect ke login
  };

  const userMenu = {
    items: [            
      {
        key: "logout",
        icon: <LogoutOutlined />,
        label: texts.logout,
        onClick: handleLogout,
      },
    ],
  };

  const languageMenu = {
    items: [
      {
        key: 'en',
        label: 'English',
        onClick: () => switchLanguage('en'),
      },
      {
        key: 'id',
        label: 'Indonesia',
        onClick: () => switchLanguage('id'),
      },
    ],
  };

  const switchLanguage = (lang: "en" | "id") => {
    setLocale(lang === "en" ? enUS : idID);
    setCurrentLang(lang);

    localStorage.setItem("lang", lang);
    document.cookie = `lang=${lang}; path=/; max-age=31536000; SameSite=Lax`;
  };

  return (
    <ConfigProvider locale={enUS}>
        <ProLayout        
          title="telkomsigma"  
          logo="/images/telkom.png"
          style={{
            height: '100vh',
          }}          
          footerRender={() => (
            <DefaultFooter              
              copyright="telkomsigma 2025"
            />
          )}
          layout="mix"
          route={{
              path: '/',
              routes: [
                { path: '/dashboard', name: 'Dashboard', icon: <DashboardOutlined />},
                {
                  path: '/user-management',
                  name: 'User Management',
                  icon: <TeamOutlined />,
                  children: [
                    { path: '/user-management/user', name: 'User' },
                    { path: '/user-management/role', name: 'Role' },
                    { path: '/user-management/menu', name: 'Menu' },
                    { path: '/user-management/permission', name: 'Permission' },
                    { path: '/user-management/role-permission', name: 'Role Permission' },
                  ],
                },
                {
                  path: '/report',
                  name: 'Report',
                  icon: <BarChartOutlined />,
                  children: [
                    { path: '/report/daily', name: 'Daily' },
                    { path: '/report/monthly', name: 'Monthly' },
                  ],
                },
              ],
            }}
            location={{ pathname: pathname || '/dashboard' }}
            onMenuHeaderClick={() => router.push('/')}
            menuItemRender={(item, dom) =>
              item.path ? <Link href={item.path}>{dom}</Link> : dom
            }                
            onPageChange={() => {
              // contoh: jika belum login -> redirect
              // if (!isLogin) router.push('/login');
            }}  
            actionsRender={() => mounted ? [
                <Dropdown key="lang" menu={languageMenu} placement="bottomRight" trigger={['click']}>
                  <Tooltip title={texts.switchLanguage} placement="left">
                    <Button type="text" shape="circle" icon={<GlobalOutlined />} size="small" />
                  </Tooltip>
                </Dropdown>,
                <Dropdown key="user" menu={userMenu} placement="bottomRight" trigger={["click"]}>
                  <Tooltip title={`${texts.hello}, ${user?.name || 'User'}!`} placement="left">
                    <Button type="text" shape="default" icon={<UserOutlined  />} size="small" />
                  </Tooltip>
                </Dropdown>,
              ] : null}                         
        >          
          <LangContext.Provider value={{ texts: locales[currentLang], currentLang, switchLanguage }}>
            {/* <PageContainer>{children}</PageContainer> */}
            {children}
          </LangContext.Provider>
        </ProLayout>   
    </ConfigProvider>                  
  );
}